 *+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+*
 * Acknowledgement: This work has benefitted from funding through the CleanSky2 Programme under Grant Agreement CS2-LPA-GAM-2016-2017-01. The authors are responsible for the content of this publication.
 *+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+**+*


- Add the libary PID_v1_own to your libary directory
- Flash Arduino 1.8 on your Arduino pending on your application you have to manipulate values here
- Run the program in the folder Arduino_Save_Receive_v2\Arduino_Save_Receive_v2\bin\Debug\Arduino_Save_Receive_v2
  Do not seperate the Datas in the folder! !!!!The GUI can not work without the needed libarys!!!!!
- Read the manual!

For any troubleshooting and suggestions with this content please contact me via mail: andreas35494@yahoo.de
DISCLAIMER
Content
The author reserves the right not to be responsible for the topicality, correctness,
completeness or quality of the information provided. Liability claims regarding
damage caused by the use of any information provided, including any kind of
information which is incomplete or incorrect, will therefore be rejected.
All offers are not-binding and without obligation. Parts of the pages or the complete
publication including all offers and information might be extended, changed or partly
or completely deleted by the author without separate announcement.
The author is not responsible for any damage to persons or machines caused by this software

For the use of the PID_V1_OWN all rights belong to Brett Beauregard (www.brettbeauregard.com)
I just made minor changements on your Library to work correctly with the GUI. The Changements do not 
affect the PID algorithm.

For the use of the kayChart.dll all rights belong to Szymon Chmielewski (https://www.nuget.org/packages/kayChart.dll/)




Andreas Bernatzky 04.09.18